package com.example.ui

import android.app.Application
import androidx.compose.ui.graphics.ImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppInfo
import com.example.data.model.AssistantVoiceState
import com.example.data.model.LaunchResult
import com.example.data.model.LauncherTab
import com.example.data.repository.AppRepository
import com.example.data.voice.VoiceManager
import com.example.domain.command.CommandInterpreter
import com.example.domain.command.CommandResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Locale

class NovaLauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val appRepository = AppRepository(application)
    private val commandInterpreter = CommandInterpreter()

    private val _allApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val allApps: StateFlow<List<AppInfo>> = _allApps.asStateFlow()

    private val _isLoading = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedTab = MutableStateFlow(LauncherTab.ALL)
    val selectedTab: StateFlow<LauncherTab> = _selectedTab.asStateFlow()

    private val _clarificationState = MutableStateFlow<Pair<String, List<AppInfo>>?>(null)
    val clarificationState: StateFlow<Pair<String, List<AppInfo>>?> = _clarificationState.asStateFlow()

    private val _lastLaunchResult = MutableStateFlow<LaunchResult?>(null)
    val lastLaunchResult: StateFlow<LaunchResult?> = _lastLaunchResult.asStateFlow()

    private val _showDefaultLauncherDialog = MutableStateFlow(false)
    val showDefaultLauncherDialog: StateFlow<Boolean> = _showDefaultLauncherDialog.asStateFlow()

    // Filtered apps based on selected tab and search query
    val filteredApps: StateFlow<List<AppInfo>> = combine(
        _allApps,
        _selectedTab,
        _searchQuery
    ) { apps, tab, query ->
        val tabFiltered = when (tab) {
            LauncherTab.ALL -> apps
            LauncherTab.FAVORITES -> apps.filter { it.isFavorite }
            LauncherTab.RECENTS -> apps
                .filter { it.lastLaunchedTimestamp > 0L }
                .sortedByDescending { it.lastLaunchedTimestamp }
        }

        if (query.isBlank()) {
            tabFiltered
        } else {
            val q = query.trim().lowercase(Locale.ROOT)
            tabFiltered.filter {
                it.label.lowercase(Locale.ROOT).contains(q) ||
                it.packageName.lowercase(Locale.ROOT).contains(q)
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Voice Manager integration
    private val voiceManager = VoiceManager(application) { spokenText ->
        processVoiceCommand(spokenText)
    }

    val voiceState: StateFlow<AssistantVoiceState> = voiceManager.voiceState
    val rmsDb: StateFlow<Float> = voiceManager.rmsDb
    val statusMessage: StateFlow<String> = voiceManager.statusMessage
    val isMuted: StateFlow<Boolean> = voiceManager.isMuted
    val isVoiceAvailable: StateFlow<Boolean> = voiceManager.isVoiceAvailable

    init {
        refreshApps()
    }

    fun refreshApps() {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                val apps = appRepository.getInstalledLaunchableApps()
                _allApps.value = apps
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun getAppIcon(packageName: String): ImageBitmap? {
        return appRepository.getAppIcon(packageName)
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectTab(tab: LauncherTab) {
        _selectedTab.value = tab
    }

    fun toggleFavorite(app: AppInfo) {
        val isNowFavorite = appRepository.toggleFavorite(app.packageName)
        _allApps.value = _allApps.value.map {
            if (it.packageName == app.packageName) it.copy(isFavorite = isNowFavorite) else it
        }
    }

    fun launchApp(app: AppInfo) {
        val result = appRepository.launchApp(app.packageName)
        _lastLaunchResult.value = result
        when (result) {
            is LaunchResult.Success -> {
                voiceManager.setStatus("Opened ${result.label}", AssistantVoiceState.IDLE)
                voiceManager.speak("Launching ${result.label}")
                // Update internal launch count and recents
                refreshApps()
            }
            is LaunchResult.Failed -> {
                voiceManager.setStatus("Failed to launch ${app.label}: ${result.reason}", AssistantVoiceState.ERROR)
                voiceManager.speak("Could not open ${app.label}")
            }
        }
    }

    fun openAppDetails(app: AppInfo) {
        appRepository.openAppDetails(app.packageName)
    }

    fun startListening() {
        _clarificationState.value = null
        voiceManager.startListening()
    }

    fun cancelListening() {
        voiceManager.cancelListening()
    }

    fun toggleMute() {
        voiceManager.toggleMute()
    }

    fun executeTextCommand(text: String) {
        if (text.isBlank()) return
        processVoiceCommand(text.trim())
    }

    private fun processVoiceCommand(input: String) {
        val result = commandInterpreter.interpret(input, _allApps.value)
        when (result) {
            is CommandResult.Launch -> {
                _clarificationState.value = null
                launchApp(result.app)
            }
            is CommandResult.Disambiguation -> {
                _clarificationState.value = Pair(result.query, result.candidates)
                voiceManager.setStatus(result.promptMessage, AssistantVoiceState.IDLE)
                voiceManager.speak("I found multiple matching apps. Please select one.")
            }
            is CommandResult.SwitchTab -> {
                _clarificationState.value = null
                _selectedTab.value = result.tab
                voiceManager.setStatus(result.feedback, AssistantVoiceState.IDLE)
                voiceManager.speak(result.feedback)
            }
            is CommandResult.Search -> {
                _clarificationState.value = null
                _searchQuery.value = result.query
                voiceManager.setStatus(result.feedback, AssistantVoiceState.IDLE)
                voiceManager.speak(result.feedback)
            }
            is CommandResult.Help -> {
                _clarificationState.value = null
                voiceManager.setStatus("Say \"Open [App]\" or \"Show favorites\"", AssistantVoiceState.IDLE)
                voiceManager.speak("You can say Open app name, or show favorites and recents.")
            }
            is CommandResult.NotFound -> {
                _clarificationState.value = null
                voiceManager.setStatus(result.feedback, AssistantVoiceState.ERROR)
                voiceManager.speak("No app found for ${result.query}")
            }
        }
    }

    fun resolveClarification(app: AppInfo) {
        _clarificationState.value = null
        launchApp(app)
    }

    fun dismissClarification() {
        _clarificationState.value = null
        voiceManager.setStatus("Tap orb or mic to speak", AssistantVoiceState.IDLE)
    }

    fun setShowDefaultLauncherDialog(show: Boolean) {
        _showDefaultLauncherDialog.value = show
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.destroy()
    }
}
