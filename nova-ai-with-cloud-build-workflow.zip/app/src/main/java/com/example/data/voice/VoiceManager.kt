package com.example.data.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.data.model.AssistantVoiceState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class VoiceManager(
    private val context: Context,
    private val onVoiceResult: (String) -> Unit
) {
    private val mainHandler = Handler(Looper.getMainLooper())

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsInitialized = false

    private val _voiceState = MutableStateFlow(AssistantVoiceState.IDLE)
    val voiceState: StateFlow<AssistantVoiceState> = _voiceState.asStateFlow()

    private val _rmsDb = MutableStateFlow(0f)
    val rmsDb: StateFlow<Float> = _rmsDb.asStateFlow()

    private val _statusMessage = MutableStateFlow("Tap orb or mic to speak")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

    private val _isVoiceAvailable = MutableStateFlow(true)
    val isVoiceAvailable: StateFlow<Boolean> = _isVoiceAvailable.asStateFlow()

    init {
        initSpeechRecognizer()
        initTextToSpeech()
    }

    private fun initSpeechRecognizer() {
        mainHandler.post {
            try {
                if (SpeechRecognizer.isRecognitionAvailable(context)) {
                    speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                        setRecognitionListener(createRecognitionListener())
                    }
                    _isVoiceAvailable.value = true
                } else {
                    _isVoiceAvailable.value = false
                    _statusMessage.value = "Voice recognition not available on device"
                }
            } catch (e: Exception) {
                _isVoiceAvailable.value = false
                _statusMessage.value = "Failed to initialize speech recognizer"
            }
        }
    }

    private fun initTextToSpeech() {
        textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech?.let { tts ->
                    val result = tts.setLanguage(Locale.getDefault())
                    if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        tts.language = Locale.US
                    }
                    tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {
                            _voiceState.value = AssistantVoiceState.SPEAKING
                        }

                        override fun onDone(utteranceId: String?) {
                            if (_voiceState.value == AssistantVoiceState.SPEAKING) {
                                _voiceState.value = AssistantVoiceState.IDLE
                            }
                        }

                        override fun onError(utteranceId: String?) {
                            if (_voiceState.value == AssistantVoiceState.SPEAKING) {
                                _voiceState.value = AssistantVoiceState.IDLE
                            }
                        }
                    })
                    isTtsInitialized = true
                }
            }
        }
    }

    fun startListening() {
        mainHandler.post {
            try {
                // Stop any ongoing speech
                stopSpeaking()

                if (speechRecognizer == null) {
                    initSpeechRecognizer()
                }

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
                }

                _voiceState.value = AssistantVoiceState.LISTENING
                _statusMessage.value = "Listening... speak now"
                speechRecognizer?.startListening(intent)
            } catch (e: Exception) {
                _voiceState.value = AssistantVoiceState.ERROR
                _statusMessage.value = "Could not start voice listener: ${e.message}"
            }
        }
    }

    fun stopListening() {
        mainHandler.post {
            try {
                speechRecognizer?.stopListening()
                if (_voiceState.value == AssistantVoiceState.LISTENING) {
                    _voiceState.value = AssistantVoiceState.PROCESSING
                    _statusMessage.value = "Processing command..."
                }
            } catch (e: Exception) {
                _voiceState.value = AssistantVoiceState.IDLE
            }
        }
    }

    fun cancelListening() {
        mainHandler.post {
            try {
                speechRecognizer?.cancel()
                _voiceState.value = AssistantVoiceState.IDLE
                _statusMessage.value = "Tap orb or mic to speak"
                _rmsDb.value = 0f
            } catch (e: Exception) {
                _voiceState.value = AssistantVoiceState.IDLE
            }
        }
    }

    fun speak(text: String) {
        if (_isMuted.value) return

        mainHandler.post {
            if (isTtsInitialized && textToSpeech != null) {
                val utteranceId = "NOVA_${System.currentTimeMillis()}"
                textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
            }
        }
    }

    fun stopSpeaking() {
        mainHandler.post {
            try {
                if (textToSpeech?.isSpeaking == true) {
                    textToSpeech?.stop()
                }
                if (_voiceState.value == AssistantVoiceState.SPEAKING) {
                    _voiceState.value = AssistantVoiceState.IDLE
                }
            } catch (e: Exception) {
                // Ignored
            }
        }
    }

    fun toggleMute(): Boolean {
        val newState = !_isMuted.value
        _isMuted.value = newState
        if (newState) {
            stopSpeaking()
        }
        return newState
    }

    fun setStatus(message: String, state: AssistantVoiceState = AssistantVoiceState.IDLE) {
        _statusMessage.value = message
        _voiceState.value = state
    }

    private fun createRecognitionListener(): RecognitionListener {
        return object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                _voiceState.value = AssistantVoiceState.LISTENING
                _statusMessage.value = "Listening... say \"Open [App]\""
            }

            override fun onBeginningOfSpeech() {
                _statusMessage.value = "Hearing your voice..."
            }

            override fun onRmsChanged(rmsdB: Float) {
                _rmsDb.value = rmsdB.coerceIn(0f, 15f)
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                _voiceState.value = AssistantVoiceState.PROCESSING
                _statusMessage.value = "Analyzing command..."
                _rmsDb.value = 0f
            }

            override fun onError(error: Int) {
                val message = when (error) {
                    SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
                    SpeechRecognizer.ERROR_CLIENT -> "Speech recognition client error"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required"
                    SpeechRecognizer.ERROR_NETWORK -> "Network connection error"
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timed out"
                    SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized. Try again."
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Assistant is busy"
                    SpeechRecognizer.ERROR_SERVER -> "Server error"
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech heard"
                    else -> "Voice recognition error ($error)"
                }
                _voiceState.value = AssistantVoiceState.ERROR
                _statusMessage.value = message
                _rmsDb.value = 0f

                // Reset to idle after delay
                mainHandler.postDelayed({
                    if (_voiceState.value == AssistantVoiceState.ERROR) {
                        _voiceState.value = AssistantVoiceState.IDLE
                        _statusMessage.value = "Tap orb or mic to speak"
                    }
                }, 3000)
            }

            override fun onResults(results: Bundle?) {
                _rmsDb.value = 0f
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val spokenText = matches?.firstOrNull()?.trim()

                if (!spokenText.isNullOrEmpty()) {
                    _voiceState.value = AssistantVoiceState.PROCESSING
                    _statusMessage.value = "\"$spokenText\""
                    onVoiceResult(spokenText)
                } else {
                    _voiceState.value = AssistantVoiceState.IDLE
                    _statusMessage.value = "Couldn't understand. Please try again."
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val partialMatches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                partialMatches?.firstOrNull()?.let { partial ->
                    if (partial.isNotBlank()) {
                        _statusMessage.value = "\"$partial...\""
                    }
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
    }

    fun destroy() {
        mainHandler.post {
            try {
                speechRecognizer?.destroy()
                speechRecognizer = null
            } catch (e: Exception) {
                // Ignored
            }
            try {
                textToSpeech?.stop()
                textToSpeech?.shutdown()
                textToSpeech = null
            } catch (e: Exception) {
                // Ignored
            }
        }
    }
}
