package com.example.data.repository

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.collection.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.example.data.model.AppInfo
import com.example.data.model.LaunchResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AppRepository(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("nova_launcher_prefs", Context.MODE_PRIVATE)

    private val iconCache = LruCache<String, ImageBitmap>(150)

    companion object {
        private const val PREF_FAVORITES = "pref_favorites_set"
        private const val PREF_RECENTS_DATA = "pref_recents_data_v1"
    }

    suspend fun getInstalledLaunchableApps(): List<AppInfo> = withContext(Dispatchers.IO) {
        val packageManager = context.packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val resolveInfos: List<ResolveInfo> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            packageManager.queryIntentActivities(
                launcherIntent,
                PackageManager.ResolveInfoFlags.of(0)
            )
        } else {
            @Suppress("DEPRECATION")
            packageManager.queryIntentActivities(launcherIntent, 0)
        }

        val favorites = getFavoritesSet()
        val recentsMap = getRecentsDataMap()

        val myPackageName = context.packageName

        val apps = mutableListOf<AppInfo>()
        for (info in resolveInfos) {
            val pkg = info.activityInfo.packageName
            // Skip the launcher itself
            if (pkg == myPackageName) continue

            val label = info.loadLabel(packageManager).toString().trim()
            val activityName = info.activityInfo.name

            val isFav = favorites.contains(pkg)
            val launchStats = recentsMap[pkg]
            val count = launchStats?.first ?: 0
            val lastTimestamp = launchStats?.second ?: 0L

            apps.add(
                AppInfo(
                    packageName = pkg,
                    label = if (label.isNotEmpty()) label else pkg,
                    activityName = activityName,
                    isFavorite = isFav,
                    launchCount = count,
                    lastLaunchedTimestamp = lastTimestamp
                )
            )
        }

        // Sort alphabetically by default
        apps.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.label })
    }

    fun getAppIcon(packageName: String): ImageBitmap? {
        iconCache.get(packageName)?.let { return it }

        return try {
            val pm = context.packageManager
            val drawable: Drawable = pm.getApplicationIcon(packageName)
            val bitmap = drawableToBitmap(drawable)
            val imageBitmap = bitmap.asImageBitmap()
            iconCache.put(packageName, imageBitmap)
            imageBitmap
        } catch (e: Exception) {
            null
        }
    }

    private fun drawableToBitmap(drawable: Drawable): Bitmap {
        if (drawable is BitmapDrawable && drawable.bitmap != null) {
            return drawable.bitmap
        }

        val width = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth else 96
        val height = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight else 96

        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bitmap
    }

    fun launchApp(packageName: String): LaunchResult {
        return try {
            val pm = context.packageManager
            val intent = pm.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                intent.addFlags(Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                context.startActivity(intent)

                recordAppLaunch(packageName)
                val label = try {
                    val appInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        pm.getApplicationInfo(packageName, PackageManager.ApplicationInfoFlags.of(0))
                    } else {
                        @Suppress("DEPRECATION")
                        pm.getApplicationInfo(packageName, 0)
                    }
                    pm.getApplicationLabel(appInfo).toString()
                } catch (e: Exception) {
                    packageName
                }
                LaunchResult.Success(packageName, label)
            } else {
                LaunchResult.Failed(packageName, "No launch intent available for $packageName")
            }
        } catch (e: Exception) {
            LaunchResult.Failed(packageName, e.localizedMessage ?: "Launch failed")
        }
    }

    fun openAppDetails(packageName: String) {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", packageName, null)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            // Ignored
        }
    }

    fun toggleFavorite(packageName: String): Boolean {
        val favs = getFavoritesSet().toMutableSet()
        val nowFavorite = if (favs.contains(packageName)) {
            favs.remove(packageName)
            false
        } else {
            favs.add(packageName)
            true
        }
        prefs.edit().putStringSet(PREF_FAVORITES, favs).apply()
        return nowFavorite
    }

    fun getFavoritesSet(): Set<String> {
        return prefs.getStringSet(PREF_FAVORITES, emptySet()) ?: emptySet()
    }

    private fun recordAppLaunch(packageName: String) {
        val recents = getRecentsDataMap().toMutableMap()
        val current = recents[packageName]
        val newCount = (current?.first ?: 0) + 1
        val newTimestamp = System.currentTimeMillis()
        recents[packageName] = Pair(newCount, newTimestamp)

        // Save serialized as pkg:count:timestamp lines
        val serialized = recents.entries.joinToString(";") { "${it.key}:${it.value.first}:${it.value.second}" }
        prefs.edit().putString(PREF_RECENTS_DATA, serialized).apply()
    }

    private fun getRecentsDataMap(): Map<String, Pair<Int, Long>> {
        val raw = prefs.getString(PREF_RECENTS_DATA, null) ?: return emptyMap()
        val result = mutableMapOf<String, Pair<Int, Long>>()
        val entries = raw.split(";")
        for (entry in entries) {
            val parts = entry.split(":")
            if (parts.size == 3) {
                val pkg = parts[0]
                val count = parts[1].toIntOrNull() ?: 0
                val ts = parts[2].toLongOrNull() ?: 0L
                result[pkg] = Pair(count, ts)
            }
        }
        return result
    }
}
