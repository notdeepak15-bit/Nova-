package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.List
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.AppInfo
import com.example.data.model.AssistantVoiceState
import com.example.data.model.LauncherTab
import com.example.ui.components.AppCard
import com.example.ui.components.ClarificationCard
import com.example.ui.components.DefaultLauncherDialog
import com.example.ui.components.GlowingOrb
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberBlack
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberBorderGlow
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningOrange

@Composable
fun NovaLauncherScreen(
    viewModel: NovaLauncherViewModel,
    onRequestRecordAudioPermission: () -> Unit,
    hasRecordAudioPermission: Boolean,
    modifier: Modifier = Modifier
) {
    val allApps by viewModel.allApps.collectAsStateWithLifecycle()
    val filteredApps by viewModel.filteredApps.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val voiceState by viewModel.voiceState.collectAsStateWithLifecycle()
    val rmsDb by viewModel.rmsDb.collectAsStateWithLifecycle()
    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()
    val isMuted by viewModel.isMuted.collectAsStateWithLifecycle()
    val isVoiceAvailable by viewModel.isVoiceAvailable.collectAsStateWithLifecycle()
    val clarificationState by viewModel.clarificationState.collectAsStateWithLifecycle()
    val showDefaultLauncherDialog by viewModel.showDefaultLauncherDialog.collectAsStateWithLifecycle()

    val focusManager = LocalFocusManager.current
    var textCommandInput by remember { mutableStateOf("") }

    if (showDefaultLauncherDialog) {
        DefaultLauncherDialog(
            onDismiss = { viewModel.setShowDefaultLauncherDialog(false) }
        )
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBackground),
        containerColor = CyberBackground,
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            val isWideScreen = maxWidth >= 600.dp

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 840.dp)
                    .align(Alignment.TopCenter)
            ) {
                // Top Action Bar
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(NeonCyan.copy(alpha = 0.2f), ElectricBlue.copy(alpha = 0.3f))
                                    )
                                )
                                .border(1.dp, NeonCyan.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                        ) {
                            Text(
                                text = "N",
                                color = NeonCyan,
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "NOVA AI",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.2.sp
                                )
                            )
                            Text(
                                text = "Smart Voice Launcher",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = NeonCyan,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Refresh apps list
                        IconButton(
                            onClick = { viewModel.refreshApps() },
                            modifier = Modifier
                                .size(44.dp)
                                .testTag("btn_refresh_apps")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Refresh installed apps",
                                tint = TextSecondary
                            )
                        }

                        // Mute/Unmute voice responses
                        IconButton(
                            onClick = { viewModel.toggleMute() },
                            modifier = Modifier
                                .size(44.dp)
                                .testTag("btn_toggle_mute")
                        ) {
                            Icon(
                                imageVector = if (isMuted) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                                contentDescription = if (isMuted) "Unmute Assistant Speech" else "Mute Assistant Speech",
                                tint = if (isMuted) WarningOrange else NeonCyan
                            )
                        }

                        // Default launcher setup button
                        IconButton(
                            onClick = { viewModel.setShowDefaultLauncherDialog(true) },
                            modifier = Modifier
                                .size(44.dp)
                                .testTag("btn_launcher_setup")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Home,
                                contentDescription = "Configure default home launcher",
                                tint = ElectricBlue
                            )
                        }
                    }
                }

                // Assistant Feedback & AI Orb Section
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    // Glowing Animated AI Orb
                    GlowingOrb(
                        state = voiceState,
                        rmsDb = rmsDb,
                        isVoiceAvailable = isVoiceAvailable,
                        onClick = {
                            if (!hasRecordAudioPermission) {
                                onRequestRecordAudioPermission()
                            } else if (voiceState == AssistantVoiceState.LISTENING) {
                                viewModel.cancelListening()
                            } else {
                                viewModel.startListening()
                            }
                        }
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Status Pill / Voice Message
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .fillMaxWidth(0.9f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(CyberSurface)
                            .border(
                                width = 1.dp,
                                color = when (voiceState) {
                                    AssistantVoiceState.LISTENING -> NeonCyan
                                    AssistantVoiceState.PROCESSING -> ElectricBlue
                                    AssistantVoiceState.ERROR -> ErrorRed
                                    else -> CyberBorder
                                },
                                shape = RoundedCornerShape(14.dp)
                            )
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = statusMessage,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = when (voiceState) {
                                    AssistantVoiceState.LISTENING -> NeonCyan
                                    AssistantVoiceState.PROCESSING -> ElectricBlue
                                    AssistantVoiceState.ERROR -> ErrorRed
                                    else -> TextPrimary
                                },
                                fontWeight = FontWeight.Medium
                            ),
                            textAlign = TextAlign.Center,
                            maxLines = 2
                        )
                    }

                    // Quick Command Suggestion Chips
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                            .horizontalScroll(rememberScrollState())
                    ) {
                        val sampleCommands = listOf(
                            "Open YouTube",
                            "Open Chrome",
                            "Open Settings",
                            "Show Favorites",
                            "Show Recents",
                            "Help"
                        )
                        sampleCommands.forEach { cmd ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(CyberSurfaceVariant)
                                    .border(1.dp, CyberBorder, RoundedCornerShape(12.dp))
                                    .clickable {
                                        viewModel.executeTextCommand(cmd)
                                    }
                                    .padding(horizontal = 10.dp, vertical = 5.dp)
                                    .testTag("chip_cmd_$cmd")
                            ) {
                                Text(
                                    text = cmd,
                                    color = NeonCyan,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    // Ambiguity Clarification card (if active)
                    clarificationState?.let { (query, candidates) ->
                        ClarificationCard(
                            query = query,
                            candidates = candidates,
                            iconProvider = { pkg -> viewModel.getAppIcon(pkg) },
                            onSelectApp = { app -> viewModel.resolveClarification(app) },
                            onDismiss = { viewModel.dismissClarification() }
                        )
                    }

                    // Text Input Fallback / Command Bar
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 10.dp)
                    ) {
                        OutlinedTextField(
                            value = textCommandInput,
                            onValueChange = { textCommandInput = it },
                            placeholder = {
                                Text(
                                    text = "Type command or app name (e.g. Open Maps)",
                                    color = TextMuted,
                                    fontSize = 13.sp
                                )
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(
                                onSend = {
                                    if (textCommandInput.isNotBlank()) {
                                        viewModel.executeTextCommand(textCommandInput)
                                        textCommandInput = ""
                                        focusManager.clearFocus()
                                    }
                                }
                            ),
                            trailingIcon = {
                                if (textCommandInput.isNotEmpty()) {
                                    IconButton(
                                        onClick = {
                                            viewModel.executeTextCommand(textCommandInput)
                                            textCommandInput = ""
                                            focusManager.clearFocus()
                                        },
                                        modifier = Modifier.testTag("btn_send_command")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Send,
                                            contentDescription = "Execute Command",
                                            tint = NeonCyan
                                        )
                                    }
                                }
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = CyberSurface,
                                unfocusedContainerColor = CyberSurface,
                                focusedBorderColor = NeonCyan,
                                unfocusedBorderColor = CyberBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_command_text")
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        // Mic trigger button
                        IconButton(
                            onClick = {
                                if (!hasRecordAudioPermission) {
                                    onRequestRecordAudioPermission()
                                } else if (voiceState == AssistantVoiceState.LISTENING) {
                                    viewModel.cancelListening()
                                } else {
                                    viewModel.startListening()
                                }
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (voiceState == AssistantVoiceState.LISTENING) NeonCyan else CyberSurfaceVariant)
                                .border(1.dp, if (voiceState == AssistantVoiceState.LISTENING) NeonCyan else CyberBorder, RoundedCornerShape(14.dp))
                                .testTag("btn_mic_action")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = if (voiceState == AssistantVoiceState.LISTENING) "Stop listening" else "Start listening",
                                tint = if (voiceState == AssistantVoiceState.LISTENING) CyberBlack else NeonCyan
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // App Navigation Tabs: [All Apps] [Favorites] [Recents]
                TabRow(
                    selectedTabIndex = selectedTab.ordinal,
                    containerColor = CyberBackground,
                    contentColor = NeonCyan,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab.ordinal]),
                            color = NeonCyan,
                            height = 3.dp
                        )
                    },
                    divider = {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(1.dp)
                                .background(CyberBorder)
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Tab(
                        selected = selectedTab == LauncherTab.ALL,
                        onClick = { viewModel.selectTab(LauncherTab.ALL) },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Outlined.List,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "All Apps (${allApps.size})",
                                    fontWeight = if (selectedTab == LauncherTab.ALL) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        },
                        selectedContentColor = NeonCyan,
                        unselectedContentColor = TextSecondary,
                        modifier = Modifier.testTag("tab_all_apps")
                    )

                    val favCount = allApps.count { it.isFavorite }
                    Tab(
                        selected = selectedTab == LauncherTab.FAVORITES,
                        onClick = { viewModel.selectTab(LauncherTab.FAVORITES) },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Favorites ($favCount)",
                                    fontWeight = if (selectedTab == LauncherTab.FAVORITES) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        },
                        selectedContentColor = NeonCyan,
                        unselectedContentColor = TextSecondary,
                        modifier = Modifier.testTag("tab_favorites")
                    )

                    val recentCount = allApps.count { it.lastLaunchedTimestamp > 0L }
                    Tab(
                        selected = selectedTab == LauncherTab.RECENTS,
                        onClick = { viewModel.selectTab(LauncherTab.RECENTS) },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Outlined.History,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Recents ($recentCount)",
                                    fontWeight = if (selectedTab == LauncherTab.RECENTS) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        },
                        selectedContentColor = NeonCyan,
                        unselectedContentColor = TextSecondary,
                        modifier = Modifier.testTag("tab_recents")
                    )
                }

                // Search Filter Bar
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { viewModel.setSearchQuery(it) },
                        placeholder = {
                            Text(
                                text = stringResource(R.string.search_apps_hint),
                                color = TextMuted,
                                fontSize = 13.sp
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Search",
                                tint = NeonCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(
                                    onClick = { viewModel.setSearchQuery("") },
                                    modifier = Modifier.testTag("btn_clear_search")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Clear,
                                        contentDescription = "Clear search",
                                        tint = TextMuted
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = CyberSurface,
                            unfocusedContainerColor = CyberSurface,
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = CyberBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_search_apps")
                    )
                }

                // Apps Content List / Grid
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(horizontal = 16.dp)
                ) {
                    when {
                        isLoading -> {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier.fillMaxSize()
                            ) {
                                CircularProgressIndicator(
                                    color = NeonCyan,
                                    modifier = Modifier.size(36.dp)
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "Discovering installed apps...",
                                    color = TextSecondary,
                                    fontSize = 13.sp
                                )
                            }
                        }

                        filteredApps.isEmpty() -> {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(24.dp)
                            ) {
                                val emptyIcon = when (selectedTab) {
                                    LauncherTab.FAVORITES -> Icons.Outlined.StarBorder
                                    LauncherTab.RECENTS -> Icons.Outlined.History
                                    LauncherTab.ALL -> Icons.Default.Search
                                }
                                Icon(
                                    imageVector = emptyIcon,
                                    contentDescription = null,
                                    tint = TextMuted,
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                val emptyText = when {
                                    searchQuery.isNotEmpty() -> "No apps matching \"$searchQuery\""
                                    selectedTab == LauncherTab.FAVORITES -> stringResource(R.string.no_favorites_yet)
                                    selectedTab == LauncherTab.RECENTS -> stringResource(R.string.no_recents_yet)
                                    else -> stringResource(R.string.no_apps_found)
                                }
                                Text(
                                    text = emptyText,
                                    color = TextSecondary,
                                    fontSize = 14.sp,
                                    textAlign = TextAlign.Center,
                                    lineHeight = 20.sp
                                )
                            }
                        }

                        else -> {
                            if (isWideScreen) {
                                // 2-column grid for tablets or wide windows
                                LazyVerticalGrid(
                                    columns = GridCells.Fixed(2),
                                    contentPadding = PaddingValues(vertical = 8.dp),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .testTag("apps_grid")
                                ) {
                                    items(
                                        items = filteredApps,
                                        key = { it.packageName }
                                    ) { app ->
                                        val icon = viewModel.getAppIcon(app.packageName)
                                        AppCard(
                                            app = app,
                                            iconBitmap = icon,
                                            onLaunch = { viewModel.launchApp(it) },
                                            onToggleFavorite = { viewModel.toggleFavorite(it) },
                                            onOpenInfo = { viewModel.openAppDetails(it) }
                                        )
                                    }
                                }
                            } else {
                                // Single-column list for handheld phones
                                LazyColumn(
                                    contentPadding = PaddingValues(vertical = 8.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .testTag("apps_list")
                                ) {
                                    items(
                                        items = filteredApps,
                                        key = { it.packageName }
                                    ) { app ->
                                        val icon = viewModel.getAppIcon(app.packageName)
                                        AppCard(
                                            app = app,
                                            iconBitmap = icon,
                                            onLaunch = { viewModel.launchApp(it) },
                                            onToggleFavorite = { viewModel.toggleFavorite(it) },
                                            onOpenInfo = { viewModel.openAppDetails(it) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
