package com.example

import com.example.data.model.AppInfo
import com.example.data.model.LauncherTab
import com.example.domain.command.CommandInterpreter
import com.example.domain.command.CommandResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class ExampleUnitTest {

    private lateinit var interpreter: CommandInterpreter
    private lateinit var mockApps: List<AppInfo>

    @Before
    fun setUp() {
        interpreter = CommandInterpreter()
        mockApps = listOf(
            AppInfo(
                packageName = "com.google.android.youtube",
                label = "YouTube",
                activityName = "com.google.android.youtube.HomeActivity"
            ),
            AppInfo(
                packageName = "com.android.chrome",
                label = "Chrome",
                activityName = "com.google.android.apps.chrome.Main"
            ),
            AppInfo(
                packageName = "com.android.settings",
                label = "Settings",
                activityName = "com.android.settings.Settings"
            ),
            AppInfo(
                packageName = "com.google.android.apps.photos",
                label = "Google Photos",
                activityName = "com.google.android.apps.photos.home.HomeActivity"
            ),
            AppInfo(
                packageName = "com.google.android.apps.docs",
                label = "Google Drive",
                activityName = "com.google.android.apps.docs.app.NewMainProxyActivity"
            ),
            AppInfo(
                packageName = "com.whatsapp",
                label = "WhatsApp",
                activityName = "com.whatsapp.Main"
            ),
            AppInfo(
                packageName = "com.instagram.android",
                label = "Instagram",
                activityName = "com.instagram.mainactivity.MainActivity"
            )
        )
    }

    @Test
    fun testOpenYouTubeCommand() {
        val result = interpreter.interpret("Open YouTube", mockApps)
        assertTrue(result is CommandResult.Launch)
        val launchResult = result as CommandResult.Launch
        assertEquals("YouTube", launchResult.app.label)
        assertEquals("com.google.android.youtube", launchResult.app.packageName)
    }

    @Test
    fun testOpenChromeNaturalLanguage() {
        val result = interpreter.interpret("please launch chrome app", mockApps)
        assertTrue(result is CommandResult.Launch)
        val launchResult = result as CommandResult.Launch
        assertEquals("Chrome", launchResult.app.label)
    }

    @Test
    fun testOpenWhatsAppCommand() {
        val result = interpreter.interpret("Open WhatsApp", mockApps)
        assertTrue(result is CommandResult.Launch)
        assertEquals("WhatsApp", (result as CommandResult.Launch).app.label)
    }

    @Test
    fun testOpenInstagramCommand() {
        val result = interpreter.interpret("Launch Instagram", mockApps)
        assertTrue(result is CommandResult.Launch)
        assertEquals("Instagram", (result as CommandResult.Launch).app.label)
    }

    @Test
    fun testShowAllAppsCommand() {
        val result = interpreter.interpret("Show all apps", mockApps)
        assertTrue(result is CommandResult.SwitchTab)
        assertEquals(LauncherTab.ALL, (result as CommandResult.SwitchTab).tab)
    }

    @Test
    fun testShowFavoritesCommand() {
        val result = interpreter.interpret("Show favorites", mockApps)
        assertTrue(result is CommandResult.SwitchTab)
        assertEquals(LauncherTab.FAVORITES, (result as CommandResult.SwitchTab).tab)
    }

    @Test
    fun testShowRecentsCommand() {
        val result = interpreter.interpret("Show recents", mockApps)
        assertTrue(result is CommandResult.SwitchTab)
        assertEquals(LauncherTab.RECENTS, (result as CommandResult.SwitchTab).tab)
    }

    @Test
    fun testAmbiguousCommand() {
        // "Google" matches both "Google Photos" and "Google Drive"
        val result = interpreter.interpret("Open Google", mockApps)
        assertTrue("Expected Disambiguation for 'Google', but got $result", result is CommandResult.Disambiguation)
        val disambiguation = result as CommandResult.Disambiguation
        assertEquals(2, disambiguation.candidates.size)
    }

    @Test
    fun testNotFoundCommand() {
        val result = interpreter.interpret("Open NonExistentAppXYZ", mockApps)
        assertTrue(result is CommandResult.NotFound)
    }
}
