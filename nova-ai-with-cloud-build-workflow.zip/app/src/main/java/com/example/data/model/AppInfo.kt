package com.example.data.model

data class AppInfo(
    val packageName: String,
    val label: String,
    val activityName: String,
    val isFavorite: Boolean = false,
    val launchCount: Int = 0,
    val lastLaunchedTimestamp: Long = 0L
)

sealed interface LaunchResult {
    data class Success(val packageName: String, val label: String) : LaunchResult
    data class Failed(val packageName: String, val reason: String) : LaunchResult
}

enum class LauncherTab {
    ALL,
    FAVORITES,
    RECENTS
}

enum class AssistantVoiceState {
    IDLE,
    LISTENING,
    PROCESSING,
    SPEAKING,
    ERROR
}
