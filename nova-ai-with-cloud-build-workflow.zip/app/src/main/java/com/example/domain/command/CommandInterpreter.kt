package com.example.domain.command

import com.example.data.model.AppInfo
import com.example.data.model.LauncherTab
import java.util.Locale
import kotlin.math.min

sealed interface CommandResult {
    data class Launch(val app: AppInfo, val feedback: String) : CommandResult
    data class Disambiguation(val query: String, val candidates: List<AppInfo>, val promptMessage: String) : CommandResult
    data class SwitchTab(val tab: LauncherTab, val feedback: String) : CommandResult
    data class Search(val query: String, val feedback: String) : CommandResult
    data class Help(val helpText: String) : CommandResult
    data class NotFound(val query: String, val feedback: String) : CommandResult
}

class CommandInterpreter {

    fun interpret(rawInput: String, installedApps: List<AppInfo>): CommandResult {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) {
            return CommandResult.NotFound("", "Please say a command like \"Open Chrome\"")
        }

        val lower = trimmed.lowercase(Locale.ROOT)

        // 1. Check for tab switching / navigation commands
        when {
            lower in listOf("show all apps", "all apps", "show apps", "apps", "open all apps", "open drawer") -> {
                return CommandResult.SwitchTab(LauncherTab.ALL, "Showing all installed apps")
            }
            lower in listOf("show favorites", "favorites", "favorite apps", "pinned apps", "show favourites", "favourites") -> {
                return CommandResult.SwitchTab(LauncherTab.FAVORITES, "Showing your favorite apps")
            }
            lower in listOf("show recents", "recents", "recent apps", "recently opened", "history") -> {
                return CommandResult.SwitchTab(LauncherTab.RECENTS, "Showing recently opened apps")
            }
            lower in listOf("help", "what can you do", "commands", "show help", "who are you") -> {
                return CommandResult.Help(
                    "You can say:\n• \"Open [App]\" (e.g. Open YouTube, Open Chrome)\n• \"Show favorites\" / \"Show recents\"\n• \"Search [name]\"\n• Or tap any app to launch"
                )
            }
            lower.startsWith("search ") || lower.startsWith("find ") -> {
                val searchTarget = lower.removePrefix("search ").removePrefix("find ").trim()
                return CommandResult.Search(searchTarget, "Filtering apps for \"$searchTarget\"")
            }
        }

        // 2. Extract app query target
        val cleanQuery = extractAppTarget(lower)
        if (cleanQuery.isEmpty()) {
            return CommandResult.NotFound(rawInput, "Could not determine which app to open")
        }

        // 3. Match against installed apps
        val exactMatches = installedApps.filter { it.label.trim().equals(cleanQuery, ignoreCase = true) }
        if (exactMatches.size == 1) {
            val app = exactMatches.first()
            return CommandResult.Launch(app, "Launching ${app.label}")
        }

        // Check for words / prefix match
        val prefixMatches = installedApps.filter {
            it.label.lowercase(Locale.ROOT).startsWith(cleanQuery)
        }
        if (prefixMatches.size == 1) {
            val app = prefixMatches.first()
            return CommandResult.Launch(app, "Launching ${app.label}")
        }

        // Check for substring / contains match
        val containsMatches = installedApps.filter {
            it.label.lowercase(Locale.ROOT).contains(cleanQuery) ||
            cleanQuery.contains(it.label.lowercase(Locale.ROOT))
        }

        if (containsMatches.size == 1) {
            val app = containsMatches.first()
            return CommandResult.Launch(app, "Launching ${app.label}")
        } else if (containsMatches.size in 2..5) {
            // Ambiguous! Ask user for clarification
            val names = containsMatches.joinToString(", ") { it.label }
            return CommandResult.Disambiguation(
                query = cleanQuery,
                candidates = containsMatches,
                promptMessage = "I found ${containsMatches.size} apps matching \"$cleanQuery\": $names. Which one would you like to open?"
            )
        } else if (containsMatches.size > 5) {
            // Filter by prefix inside contains
            val bestMatches = containsMatches.filter { it.label.lowercase(Locale.ROOT).startsWith(cleanQuery) }
            if (bestMatches.size in 1..4) {
                if (bestMatches.size == 1) {
                    return CommandResult.Launch(bestMatches.first(), "Launching ${bestMatches.first().label}")
                }
                return CommandResult.Disambiguation(
                    query = cleanQuery,
                    candidates = bestMatches,
                    promptMessage = "Multiple apps match \"$cleanQuery\". Please select one:"
                )
            }
        }

        // Acronym match (e.g., "yt" -> "YouTube", "ps" -> "Play Store")
        val acronymMatches = installedApps.filter { app ->
            val acronym = app.label.split(" ").mapNotNull { it.firstOrNull()?.lowercaseChar() }.joinToString("")
            acronym == cleanQuery
        }
        if (acronymMatches.size == 1) {
            val app = acronymMatches.first()
            return CommandResult.Launch(app, "Launching ${app.label}")
        }

        // Fuzzy match using Levenshtein distance
        val scored = installedApps.map { app ->
            val distance = levenshteinDistance(cleanQuery, app.label.lowercase(Locale.ROOT))
            val maxLen = maxOf(cleanQuery.length, app.label.length)
            val score = 1.0f - (distance.toFloat() / maxLen.toFloat())
            Pair(app, score)
        }.filter { it.second >= 0.70f }
         .sortedByDescending { it.second }

        if (scored.isNotEmpty()) {
            val topScore = scored.first().second
            val closeMatches = scored.filter { it.second >= topScore - 0.1f }.take(3).map { it.first }

            if (closeMatches.size == 1) {
                val app = closeMatches.first()
                return CommandResult.Launch(app, "Launching ${app.label}")
            } else {
                return CommandResult.Disambiguation(
                    query = cleanQuery,
                    candidates = closeMatches,
                    promptMessage = "Did you mean one of these apps?"
                )
            }
        }

        return CommandResult.NotFound(
            cleanQuery,
            "No installed app found matching \"$cleanQuery\". Check spelling or browse below."
        )
    }

    private fun extractAppTarget(input: String): String {
        var result = input
        // Common conversational prefixes
        val prefixes = listOf(
            "please open ", "please launch ", "can you open ", "can you launch ",
            "open the ", "launch the ", "start the ", "run the ", "go to the ",
            "open ", "launch ", "start ", "run ", "go to ", "execute "
        )

        for (prefix in prefixes) {
            if (result.startsWith(prefix)) {
                result = result.removePrefix(prefix).trim()
                break
            }
        }

        // Remove trailing "app" or "application"
        if (result.endsWith(" application")) {
            result = result.removeSuffix(" application").trim()
        } else if (result.endsWith(" app")) {
            result = result.removeSuffix(" app").trim()
        }

        // Remove punctuation
        result = result.replace(Regex("[^a-zA-Z0-9\\s]"), "").trim()

        return result
    }

    private fun levenshteinDistance(s1: String, s2: String): Int {
        val dp = Array(s1.length + 1) { IntArray(s2.length + 1) }

        for (i in 0..s1.length) dp[i][0] = i
        for (j in 0..s2.length) dp[0][j] = j

        for (i in 1..s1.length) {
            for (j in 1..s2.length) {
                val cost = if (s1[i - 1] == s2[j - 1]) 0 else 1
                dp[i][j] = min(
                    dp[i - 1][j] + 1,
                    min(
                        dp[i][j - 1] + 1,
                        dp[i - 1][j - 1] + cost
                    )
                )
            }
        }
        return dp[s1.length][s2.length]
    }
}
