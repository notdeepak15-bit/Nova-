package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.LauncherTab
import com.example.ui.NovaLauncherScreen
import com.example.ui.NovaLauncherViewModel
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: NovaLauncherViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                var hasAudioPermission by remember {
                    mutableStateOf(
                        ContextCompat.checkSelfPermission(
                            this,
                            Manifest.permission.RECORD_AUDIO
                        ) == PackageManager.PERMISSION_GRANTED
                    )
                }

                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { isGranted ->
                    hasAudioPermission = isGranted
                    if (isGranted) {
                        viewModel.startListening()
                    }
                }

                val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
                val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
                val clarificationState by viewModel.clarificationState.collectAsStateWithLifecycle()

                // Launcher BackHandler: handle internal state gracefully before system navigation
                BackHandler(enabled = true) {
                    when {
                        clarificationState != null -> {
                            viewModel.dismissClarification()
                        }
                        searchQuery.isNotEmpty() -> {
                            viewModel.setSearchQuery("")
                        }
                        selectedTab != LauncherTab.ALL -> {
                            viewModel.selectTab(LauncherTab.ALL)
                        }
                        else -> {
                            // Standard launcher home behavior: stay on home
                            moveTaskToBack(false)
                        }
                    }
                }

                NovaLauncherScreen(
                    viewModel = viewModel,
                    onRequestRecordAudioPermission = {
                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    },
                    hasRecordAudioPermission = hasAudioPermission
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Refresh apps list in case an app was installed or uninstalled
        viewModel.refreshApps()
    }
}
