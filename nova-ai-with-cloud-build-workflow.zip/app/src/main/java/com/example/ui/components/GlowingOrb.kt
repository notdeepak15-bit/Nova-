package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Icon
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.example.data.model.AssistantVoiceState
import com.example.ui.theme.CyberBlack
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.NeonCyan
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun GlowingOrb(
    state: AssistantVoiceState,
    rmsDb: Float,
    isVoiceAvailable: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb_transition")

    // Slow continuous rotation for outer ring
    val outerRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "outer_rotation"
    )

    // Reverse rotation for inner ring
    val innerRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 5000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "inner_rotation"
    )

    // Breathing pulse for core glow
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    // Calculate dynamic boost from audio RMS volume
    val audioBoost = if (state == AssistantVoiceState.LISTENING) {
        (rmsDb / 15f).coerceIn(0f, 0.45f)
    } else 0f

    val primaryGlowColor = when (state) {
        AssistantVoiceState.ERROR -> ErrorRed
        AssistantVoiceState.LISTENING -> NeonCyan
        AssistantVoiceState.PROCESSING -> ElectricBlue
        AssistantVoiceState.SPEAKING -> NeonCyan
        AssistantVoiceState.IDLE -> NeonCyan
    }

    val secondaryGlowColor = when (state) {
        AssistantVoiceState.ERROR -> Color(0xFFB91C1C)
        AssistantVoiceState.LISTENING -> ElectricBlue
        AssistantVoiceState.PROCESSING -> Color(0xFF8B5CF6)
        AssistantVoiceState.SPEAKING -> ElectricBlue
        AssistantVoiceState.IDLE -> ElectricBlue
    }

    val statusDescription = when (state) {
        AssistantVoiceState.LISTENING -> "NOVA listening to your voice. Tap to cancel."
        AssistantVoiceState.PROCESSING -> "NOVA processing command."
        AssistantVoiceState.SPEAKING -> "NOVA speaking response."
        AssistantVoiceState.ERROR -> "Voice error occurred. Tap to retry."
        AssistantVoiceState.IDLE -> "NOVA Voice Assistant ready. Tap to speak command."
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(150.dp)
            .clip(CircleShape)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = false, radius = 80.dp),
                role = Role.Button,
                onClick = onClick
            )
            .semantics {
                contentDescription = statusDescription
            }
            .testTag("nova_voice_orb")
    ) {
        Canvas(modifier = Modifier.size(150.dp)) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val baseRadius = size.minDimension / 2.3f
            val currentPulse = (pulseScale + audioBoost).coerceAtLeast(0.85f)

            // 1. Outer ambient radial aura
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryGlowColor.copy(alpha = 0.40f + audioBoost),
                        secondaryGlowColor.copy(alpha = 0.18f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = baseRadius * 1.35f * currentPulse
                ),
                radius = baseRadius * 1.35f * currentPulse,
                center = center
            )

            // 2. Outermost rotating dashed orbital track
            drawCircle(
                color = primaryGlowColor.copy(alpha = 0.5f),
                radius = baseRadius * 1.08f,
                center = center,
                style = Stroke(
                    width = 2.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(24f, 18f), outerRotation)
                )
            )

            // 3. Counter-rotating segmented ring
            drawCircle(
                color = secondaryGlowColor.copy(alpha = 0.7f),
                radius = baseRadius * 0.90f * currentPulse,
                center = center,
                style = Stroke(
                    width = 2.5.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(36f, 22f), innerRotation)
                )
            )

            // 4. Orbiting satellite energy particles
            val satelliteAngle = Math.toRadians(outerRotation.toDouble())
            val satDistance = baseRadius * 1.08f
            val satX = center.x + (satDistance * cos(satelliteAngle)).toFloat()
            val satY = center.y + (satDistance * sin(satelliteAngle)).toFloat()
            drawCircle(
                color = primaryGlowColor,
                radius = 4.dp.toPx(),
                center = Offset(satX, satY)
            )

            val oppAngle = Math.toRadians((outerRotation + 180.0) % 360.0)
            val oppX = center.x + (satDistance * cos(oppAngle)).toFloat()
            val oppY = center.y + (satDistance * sin(oppAngle)).toFloat()
            drawCircle(
                color = secondaryGlowColor,
                radius = 3.dp.toPx(),
                center = Offset(oppX, oppY)
            )

            // 5. Solid Glowing Core
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.95f),
                        primaryGlowColor,
                        secondaryGlowColor.copy(alpha = 0.85f),
                        CyberBlack
                    ),
                    center = center,
                    radius = baseRadius * 0.65f * currentPulse
                ),
                radius = baseRadius * 0.65f * currentPulse,
                center = center
            )

            // 6. Audio wave ripple when listening
            if (state == AssistantVoiceState.LISTENING) {
                drawCircle(
                    color = primaryGlowColor.copy(alpha = (0.7f - audioBoost).coerceAtLeast(0.2f)),
                    radius = baseRadius * (0.75f + audioBoost * 0.8f),
                    center = center,
                    style = Stroke(width = 3.dp.toPx())
                )
            }
        }

        // Center Icon Indicator
        val icon = when {
            !isVoiceAvailable -> Icons.Default.MicOff
            state == AssistantVoiceState.LISTENING -> Icons.Default.GraphicEq
            state == AssistantVoiceState.PROCESSING -> Icons.Default.Sync
            state == AssistantVoiceState.SPEAKING -> Icons.Default.GraphicEq
            else -> Icons.Default.Mic
        }

        Icon(
            imageVector = icon,
            contentDescription = null, // Handled by parent semantics
            tint = CyberBlack,
            modifier = Modifier.size(36.dp)
        )
    }
}
