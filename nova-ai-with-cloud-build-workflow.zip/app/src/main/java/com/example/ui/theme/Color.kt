package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberBlack = Color(0xFF040814)
val CyberBackground = Color(0xFF070D1E)
val CyberSurface = Color(0xFF0D172E)
val CyberSurfaceVariant = Color(0xFF132242)
val CyberBorder = Color(0xFF1E3A6E)
val CyberBorderGlow = Color(0xFF00F0FF)

val NeonCyan = Color(0xFF00F0FF)
val NeonCyanDim = Color(0xFF00A8B5)
val NeonCyanGlow = Color(0x3300F0FF)

val ElectricBlue = Color(0xFF3B82F6)
val DeepBlue = Color(0xFF1D4ED8)
val ElectricBlueGlow = Color(0x333B82F6)

val CyberPurple = Color(0xFF8B5CF6)
val CyberPurpleDim = Color(0xFF6D28D9)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val SuccessGreen = Color(0xFF10B981)
val ErrorRed = Color(0xFFEF4444)
val WarningOrange = Color(0xFFF59E0B)
val FavoriteGold = Color(0xFFFFD700)
